import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    // Images come from /public and from URLs entered in the admin dashboard
    // (any host), and are already web-sized — serve them as-is.
    unoptimized: true,
  },
};

export default nextConfig;
